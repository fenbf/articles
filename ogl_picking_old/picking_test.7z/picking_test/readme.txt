simple picking app
Bartlomiej Filipek
bfilipek.com

LMB - rotate the scene & select, drag a ball
RMB - glut menu
MMB - zoom

use on your own risk :)
