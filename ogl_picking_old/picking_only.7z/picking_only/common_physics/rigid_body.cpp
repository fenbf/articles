/** @file rigid_body.cpp
 *  @brief implementation of rigid bodies base structures
 *
 *	@author Bartlomiej Filipek
 *	@date May 2011
 */

#include "stdafx.h"
#include "material_point.h"
#include "rigid_body.h"

///////////////////////////////////////////////////////////////////////////////
// RigidBody
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
RigidBody::RigidBody(Vec3d pos, Vec3d vel, Vec3d angVel, Matrix3d momentOfInertiaTensor) 
{
	m_massCenter.m_pos = pos;
	m_massCenter.m_vel = vel;
	m_massCenter.Reset();

	m_angularVel = angVel;

#ifdef USE_QUATERNIONS_FOR_ROTATIONS
	m_rotation = m_prevRotation = AxisRotationToQuaternion(&vel, 0.0);
#else
	Identity(&m_rotation);
	Identity(&m_prevRotation);
#endif

	m_momentOfInertiaTensor = momentOfInertiaTensor;
	Inverse(m_momentOfInertiaTensor, &m_momentOfInertiaTensorInv);

	m_stepCounter = 0;
}

///////////////////////////////////////////////////////////////////////////////
RigidBody::RigidBody() :
	m_angularVel(0.0, 1.0, 0.0)
{
#ifdef USE_QUATERNIONS_FOR_ROTATIONS
	m_rotation = m_prevRotation = AxisRotationToQuaternion(&m_angularVel, 0.0);
#else
	Identity(&m_rotation);
	Identity(&m_prevRotation);
#endif

	Identity(&m_momentOfInertiaTensor); 
	Identity(&m_momentOfInertiaTensorInv);

	m_stepCounter = 0;
}

///////////////////////////////////////////////////////////////////////////////
RigidBody::~RigidBody()
{

}

///////////////////////////////////////////////////////////////////////////////
void RigidBody::PrepareRotationEuler(const Vec3d& momentOfForce, double deltaTime)
{
	// acceleration:
	Vec3d temp = TransformVec3(m_momentOfInertiaTensor, m_angularVel);
	Vec3d cross = CrossProduct(m_angularVel, temp);
	Vec3d vec = momentOfForce - cross;
	Vec3d angVelDerviative = TransformVec3(m_momentOfInertiaTensorInv, vec);
	m_nextAngularVel = m_angularVel + angVelDerviative * deltaTime;

	// velocity
#ifdef USE_QUATERNIONS_FOR_ROTATIONS
	Quaterniond quatDerviative = Quaterniond(0,m_angularVel.x, m_angularVel.y, m_angularVel.z) * m_rotation * 0.5;
	m_nextRotation = m_rotation + quatDerviative * deltaTime;
	Normalize(&m_nextRotation);
#else
	Matrix3d rotMatrixDerviative = StarOperator(m_angularVel) * m_rotation;
	m_nextRotation = m_rotation + rotMatrixDerviative * deltaTime;
#endif
}

///////////////////////////////////////////////////////////////////////////////
void RigidBody::PrepareMove(const Vec3d& force, const Vec3d& momentOfForce, double deltaTime)
{
	m_massCenter.PrepareMove(deltaTime, force);
	PrepareRotationEuler(momentOfForce, deltaTime);
}

///////////////////////////////////////////////////////////////////////////////
void RigidBody::UpdateMove()
{
	m_prevRotation = m_rotation;	
	m_rotation = m_nextRotation;

	m_angularVel = m_nextAngularVel;
	m_massCenter.UpdateMove();
	
	++m_stepCounter;
}

///////////////////////////////////////////////////////////////////////////////
// RigidBodySet
///////////////////////////////////////////////////////////////////////////////
RigibBodySet::RigibBodySet(unsigned int count)
{
	m_count = count;

	// allocate memory:
	m_bodies = new RigidBody[count];
	m_bounds = new bool[count];

	// default:
	for (unsigned int i = 0; i < count; ++i)
		m_bounds[i] = false;
}

RigibBodySet::~RigibBodySet()
{
	delete [] m_bodies;
	m_bodies = NULL;
	delete [] m_bounds;
	m_bounds = NULL;
}

void RigibBodySet::Update(double deltaTime)
{
	BeforeStep(deltaTime);
	
	Vec3d force, momentOfForce;
	for (unsigned int i = 0; i < m_count; ++i)
	{
		if (m_bounds[i] == false)
		{
			ForceAndMomentOfForce(i, &force, &momentOfForce);
			m_bodies[i].PrepareMove(force, momentOfForce, deltaTime);
		}
	}

	AfterStep(deltaTime);

	for (unsigned int i = 0; i < m_count; ++i)
	{
		if (m_bounds[i] == false)
			m_bodies[i].UpdateMove();
	}
}